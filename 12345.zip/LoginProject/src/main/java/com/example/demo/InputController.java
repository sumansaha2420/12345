package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.User;



@RestController
public class InputController 
{
	@Autowired
	private RestTemplate rest;
	
	@RequestMapping("/Login")
	public ModelAndView LoginPage()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("LoginPage.jsp");
		return mv;
	}

	@RequestMapping("/Registration/submit")
	public String RegPge()
	{
		User user=new User();
		try {
		rest.postForObject("http://localhost:8082/second", user, String.class);
		}
		catch (HttpStatusCodeException e) {
			// TODO: handle exception
			e.getMessage();
		}
		return "Registration Successful";
	}
	
	
	@RequestMapping("/Registration")
	public ModelAndView home()
	{
		ModelAndView  mv = new ModelAndView(); 
		  mv.setViewName("Registration.jsp");
	      return mv;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
