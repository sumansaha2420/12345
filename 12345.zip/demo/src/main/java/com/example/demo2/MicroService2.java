package com.example.demo2;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo2.dao.UserRepo;


@Controller
public class MicroService2 {
	
	@Autowired
	UserRepo r;
	
	@RequestMapping("/second")
	public String home(@RequestBody User user)
	{
		r.save(user);
		System.out.println(user);
		return "";
	}
}
